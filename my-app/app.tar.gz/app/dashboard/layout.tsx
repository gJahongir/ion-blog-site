'use client';

import React, { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import DashboardSidebar from '../component/dashboard/DashboardSidebar';
import { Navbar } from "@/app/component";
import { useColorMode } from '../context/ThemeContext';
import { Box, Typography } from '@mui/material';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const { mode } = useColorMode();
  
  // Dastlabki holatda "tekshirilmoqda" holati
  const [status, setStatus] = useState<'loading' | 'authorized' | 'unauthorized'>('loading');

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    
    // Agar login sahifasida bo'lsak
    if (pathname === '/dashboard/login') {
      setStatus('authorized');
      return;
    }

    // Agar token yo'q bo'lsa
    if (!token) {
      setStatus('unauthorized');
      router.replace('/dashboard/login'); // .push o'rniga .replace ishlatamiz
    } else {
      setStatus('authorized');
    }
  }, [pathname, router]);

  // Yuklanish jarayoni
  if (status === 'loading') {
    return (
      <Box className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <Typography className="text-white">Xavfsizlik tekshirilmoqda...</Typography>
      </Box>
    );
  }

  // Login sahifasi uchun alohida ko'rinish
  if (pathname === '/dashboard/login') {
    return <>{children}</>;
  }

  // Faqat ruxsat berilganlar uchun dashboard ko'rinadi
  if (status === 'authorized') {
    return (
      <Box className={`min-h-screen transition-colors duration-500 ${
        mode === 'dark' ? 'bg-[#0a0a0a] text-gray-100' : 'bg-[#f5f5f5] text-gray-900'
      }`}>
        <DashboardSidebar />
        <div className="pl-64 flex flex-col min-h-screen">
          <Navbar />
          <main className="p-8 mt-20 flex-1 overflow-y-auto">
            {children}
          </main>
        </div>
      </Box>
    );
  }

  return null;
}
